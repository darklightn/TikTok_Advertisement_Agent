"""First-stage table builders."""
