'use strict';
const fs=require('fs'),path=require('path');
const {validateReportSpec}=require('../../common/md-spec-validator');
const {countXlsxDataRows}=require('../../common/official_download_rows');
const {writeWorkbook}=require('../../common/xlsx_writer');
const {dismissBlockingOverlay,validateBlockingOverlay}=require('../../common/ui-blocking-overlay');
const {sha256}=require('../common/gmvmax_campaign_product_creative_performance_v3');
const PROVIDER_ID='local',FATAL=new Set(['browser_disconnected','browser_context_missing','seller_page_missing','seller_origin_mismatch','provider_binding_invalid']);
function fail(code){throw Object.assign(new Error(code),{code});}function obj(v){return v&&typeof v==='object'&&!Array.isArray(v);}function text(v){return typeof v==='string'&&!!v.trim();}function digits(v){return /^\d+$/u.test(String(v||''));}function norm(v){return String(v||'').normalize('NFKC').trim().replace(/\s+/gu,' ');}function date(v){const d=new Date(`${v}T00:00:00Z`);return /^\d{4}-\d{2}-\d{2}$/u.test(v)&&!Number.isNaN(d.valueOf())&&d.toISOString().slice(0,10)===v;}
function validateSpec(spec,p,o={}){try{validateReportSpec(spec,o);}catch{fail('creative_performance_report_spec_invalid');}const r=p?.official_validation,f=['entry_path','campaign_row_selector','campaign_action_selector','campaign_url_query','product_row_selector','product_action_selector','product_url_query','product_tab_query','product_tab_value','date_root_selector','date_input_selector','date_trigger_selector','date_panel_selector','date_header_selector','date_header_control_selector','date_cell_selector','creative_root_selector','creative_table_selector','creative_header_text','creative_row_selector','export_selector','export_loading_class','zero_text','filename_template'],dc=r?.download_capture;if(spec?.report_id!=='gmvmax_campaign_product_creative_performance'||spec.enabled!==true||spec.owner_scope!=='product'||spec.time_semantics!=='requested_range'||spec.output_granularity!=='request_range'||spec.source_type!=='official_download'||spec.success_output_type!=='official_xlsx'||spec.no_data_output_type!=='generated_xlsx'||spec.no_data_rule!=='official_creative_total_zero'||spec.providers?.[PROVIDER_ID]!==p||p?.transport!=='seller_ui_four_step_official_download'||!obj(r)||f.some(k=>!text(r[k]))||!validateBlockingOverlay(r.blocking_overlay)||!Number.isInteger(r.date_max_month_moves)||r.date_max_month_moves<1||!Number.isInteger(r.date_refresh_settle_ms)||r.date_refresh_settle_ms<0||r.download_batch_size!==3||r.download_start_timeout_ms!==30000||r.download_retry_limit!==1||!obj(dc)||dc.mode!=='cdp_forced_staging_poll'||!Number.isInteger(dc.poll_interval_ms)||dc.poll_interval_ms<1||!Number.isInteger(dc.stable_polls)||dc.stable_polls<2||![r.navigation_timeout_ms,r.picker_timeout_ms].every(v=>Number.isInteger(v)&&v>0)||r.download_timeout_ms!==1200000||r.data_start_row!==2)fail('creative_performance_report_spec_invalid');let u;try{u=new URL(p.response_origin);}catch{fail('creative_performance_report_spec_invalid');}if(u.protocol!=='https:'||u.origin!==p.response_origin||!r.entry_path.startsWith('/'))fail('creative_performance_report_spec_invalid');return spec;}
function active(page,origin){try{const u=new URL(page.url());return u.origin===origin&&!/(?:login|signin)(?:\/|$)/iu.test(u.pathname);}catch{return false;}}function session(c){if(!c.browser?.isConnected?.())fail('browser_disconnected');if(!c.browserContext||!c.browser.contexts?.().includes(c.browserContext))fail('browser_context_missing');if(!c.browserContext.pages?.().includes(c.page))fail('seller_page_missing');if(!active(c.page,c.origin))fail('seller_origin_mismatch');}
function inputContext(i,d){if(i?.shop?.provider_id!==PROVIDER_ID)fail('report_provider_unsupported');validateSpec(i?.reportSpec,i?.providerSpec,{skillRoot:d.skillRoot});if(!obj(i.a)||!obj(i.b)||!obj(i.shop)||!digits(i.shop.seller_id)||!digits(i.advertiserId)||!digits(i.businessCenterId)||!d.browser||!d.browserContext||!date(i.startDate)||!date(i.endDate)||i.startDate>i.endDate||(i.campaignRef!=null&&!text(i.campaignRef))||(i.productRef!=null&&!text(i.productRef)))fail('creative_performance_input_invalid');const outputDir=path.resolve(String(i.outputDir||''));if(!fs.statSync(outputDir,{throwIfNoEntry:false})?.isDirectory()||fs.readdirSync(outputDir).length)fail('output_directory_invalid');let origin;try{origin=new URL(i.b.seller_page_url).origin;}catch{fail('provider_binding_invalid');}if(origin!==i.providerSpec.response_origin)fail('provider_binding_invalid');const page=d.browserContext.pages().find(p=>active(p,origin));if(!page)fail('seller_page_missing');const c={browser:d.browser,browserContext:d.browserContext,page,origin,outputDir};session(c);return c;}
async function visible(loc){const a=[];for(let n=0;n<await loc.count();n++)if(await loc.nth(n).isVisible())a.push(loc.nth(n));return a;}async function poll(check,timeout,code){const end=Date.now()+timeout;do{try{const result=await check();if(result)return result;}catch{}if(Date.now()>=end)break;await new Promise(resolve=>setTimeout(resolve,20));}while(true);fail(code);}async function actionRows(page,rowSelector,actionSelector,timeout,code){return poll(async()=>{const rows=page.locator(rowSelector),indexes=[];for(let n=0;n<await rows.count();n++){const row=rows.nth(n);if(await row.isVisible()&&(await visible(row.locator(actionSelector))).length===1)indexes.push(n);}return indexes.length?indexes:null;},timeout,code);}async function actionAt(page,rowSelector,actionSelector,index,timeout,code){return poll(async()=>{const row=page.locator(rowSelector).nth(index);if(!await row.isVisible())return null;const actions=await visible(row.locator(actionSelector));return actions.length===1?{row,action:actions[0]}:null;},timeout,code);}async function clickForUrl(page,predicate,action,timeout,code){const pending=page.waitForURL(predicate,{timeout}).catch(()=>fail(code));await action.click();await pending;}function chosen(a,ref,kind){if(!a.length)fail(`${kind}_discovery_failed`);if(ref==null)return a;const w=norm(ref),m=a.filter(x=>digits(w)?x.id===w:x.name===w);if(!m.length)fail(`explicit_${kind}_not_found_in_report_universe`);if(m.length>1)fail(`explicit_${kind}_ambiguous`);return m;}function name(s,f){return String(s||'').split(/\r?\n/u).map(norm).find(Boolean)||f;}
async function entry(c,r){await c.page.goto(new URL(r.entry_path,c.origin).href,{waitUntil:'domcontentloaded',timeout:r.navigation_timeout_ms});session(c);}async function campaignAction(c,r,index){await entry(c,r);const ready=await actionAt(c.page,r.campaign_row_selector,r.campaign_action_selector,index,r.navigation_timeout_ms,'campaign_discovery_failed'),n=name(await ready.row.innerText(),`campaign-${index+1}`);await clickForUrl(c.page,value=>{try{return digits(new URL(value).searchParams.get(r.campaign_url_query));}catch{return false;}},ready.action,r.navigation_timeout_ms,'campaign_discovery_failed');session(c);const id=new URL(c.page.url()).searchParams.get(r.campaign_url_query);return{index,id,name:n};}async function campaigns(c,r,ref){await entry(c,r);const indexes=await actionRows(c.page,r.campaign_row_selector,r.campaign_action_selector,r.navigation_timeout_ms,'campaign_discovery_failed'),a=[];for(const index of indexes){const ready=await actionAt(c.page,r.campaign_row_selector,r.campaign_action_selector,index,r.navigation_timeout_ms,'campaign_discovery_failed');let config;try{config=JSON.parse(await ready.action.getAttribute('data-btm-config'));}catch{fail('campaign_discovery_failed');}const id=String(config?.params?.campaign_id||'');if(!digits(id))fail('campaign_discovery_failed');a.push({index,id,name:name(await ready.row.innerText(),`campaign-${index+1}`)});}return chosen(a,ref,'campaign');}async function openCampaign(c,r,x){const y=await campaignAction(c,r,x.index);if(y.id!==x.id)fail('campaign_context_mismatch');}
function productIdentity(value,index){const lines=String(value||'').split(/\r?\n/u).map(norm).filter(Boolean),ids=lines.filter(item=>/^\d{10,}$/u.test(item));if(ids.length!==1)fail('product_discovery_failed');return{index,id:ids[0],name:lines[0]||`product-${index+1}`};}async function productAction(c,r,campaign,index){await openCampaign(c,r,campaign);const ready=await actionAt(c.page,r.product_row_selector,r.product_action_selector,index,r.navigation_timeout_ms,'product_discovery_failed'),identity=productIdentity(await ready.row.innerText(),index);await clickForUrl(c.page,value=>{try{const u=new URL(value);return u.searchParams.get(r.campaign_url_query)===campaign.id&&digits(u.searchParams.get(r.product_url_query))&&u.searchParams.get(r.product_tab_query)===r.product_tab_value;}catch{return false;}},ready.action,r.navigation_timeout_ms,'product_discovery_failed');session(c);const id=new URL(c.page.url()).searchParams.get(r.product_url_query);if(id!==identity.id)fail('product_context_mismatch');return identity;}async function products(c,r,campaign,ref){await openCampaign(c,r,campaign);const indexes=await actionRows(c.page,r.product_row_selector,r.product_action_selector,r.navigation_timeout_ms,'product_discovery_failed'),a=[];for(const index of indexes)a.push(await productAction(c,r,campaign,index));return chosen(a,ref,'product');}async function productChoices(c,r,campaign,ref){await openCampaign(c,r,campaign);const indexes=await actionRows(c.page,r.product_row_selector,r.product_action_selector,r.navigation_timeout_ms,'product_discovery_failed'),a=[];for(const index of indexes){const ready=await actionAt(c.page,r.product_row_selector,r.product_action_selector,index,r.navigation_timeout_ms,'product_discovery_failed');a.push(productIdentity(await ready.row.innerText(),index));}return ref==null?a:chosen(a,ref,'product');}
const ENGLISH_MONTHS=['january','february','march','april','may','june','july','august','september','october','november','december'];function monthKey(value){const normalized=norm(value).toLowerCase();let match=normalized.match(/(\d{4})\D+(\d{1,2})/u),year,month;if(match){year=Number(match[1]);month=Number(match[2]);}else{match=normalized.match(/\b([a-z]+)\b[\s,./-]+(\d{4})\b/u);if(!match)return null;year=Number(match[2]);month=ENGLISH_MONTHS.indexOf(match[1])+1;}return Number.isInteger(year)&&month>=1&&month<=12?`${year}-${String(month).padStart(2,'0')}`:null;}function monthIndex(value){const key=monthKey(value);return key?Number(key.slice(0,4))*12+Number(key.slice(5,7))-1:null;}async function dateControl(page,r){return poll(async()=>{const controls=await visible(page.locator(r.date_root_selector));if(controls.length!==1)return null;const inputs=await visible(controls[0].locator(r.date_input_selector));return inputs.length===2?{control:controls[0],inputs}:null;},r.picker_timeout_ms,'creative_date_picker_not_ready');}async function triggerPanels(page,r){return poll(async()=>{const triggers=await visible(page.locator(r.date_trigger_selector));if(triggers.length!==1)return null;const panels=await visible(triggers[0].locator(r.date_panel_selector));return panels.length===2?{trigger:triggers[0],panels}:null;},r.picker_timeout_ms,'creative_date_picker_not_ready');}async function panelMonths(panels,r){const values=[];for(const panel of panels){const headers=await visible(panel.locator(r.date_header_selector));if(headers.length!==1)fail('creative_date_picker_not_ready');const value=monthIndex(await headers[0].innerText());if(value===null)fail('creative_date_picker_not_ready');values.push(value);}return values;}async function monthPanel(page,month,r){const target=monthIndex(month);for(let move=0;move<=r.date_max_month_moves;move++){const current=await triggerPanels(page,r),shown=await panelMonths(current.panels,r),found=shown.indexOf(target);if(found!==-1)return current.panels[found];if(move===r.date_max_month_moves)break;const backwards=target<shown[0],panel=backwards?current.panels[0]:current.panels.at(-1),controls=await visible(panel.locator(r.date_header_control_selector));if(!controls.length)fail('creative_date_picker_not_ready');const before=shown.join(',');await(backwards?controls.at(-1):controls[0]).click();await poll(async()=>{const next=await triggerPanels(page,r);return(await panelMonths(next.panels,r)).join(',')!==before?true:null;},r.picker_timeout_ms,'creative_date_month_unreachable');}fail('creative_date_month_unreachable');}async function pickDay(page,value,r){const panel=await monthPanel(page,value.slice(0,7),r),cells=await visible(panel.locator(r.date_cell_selector)),matches=[];for(const cell of cells)if(norm(await cell.innerText())===String(Number(value.slice(8,10))))matches.push(cell);if(matches.length!==1)fail('creative_date_cell_missing');await matches[0].click();}
async function applyDateRange(page,start,end,r){const initial=await dateControl(page,r);await initial.control.click();await triggerPanels(page,r);await pickDay(page,start,r);await pickDay(page,end,r);await poll(async()=>{const current=await dateControl(page,r),values=await Promise.all(current.inputs.map(input=>input.inputValue()));return values[0]===start&&values[1]===end?true:null;},r.picker_timeout_ms,'creative_date_not_applied');if(r.date_refresh_settle_ms)await new Promise(resolve=>setTimeout(resolve,r.date_refresh_settle_ms));}
async function creativeState(page,r){return poll(async()=>{const roots=await visible(page.locator(r.creative_root_selector));if(roots.length!==1)return null;const root=roots[0],tables=await visible(root.locator(r.creative_table_selector));if(tables.length!==1)return null;const headers=await visible(tables[0].getByText(r.creative_header_text,{exact:true}));if(headers.length!==1)return null;const rowCount=await tables[0].locator(r.creative_row_selector).count(),zero=await visible(root.getByText(r.zero_text,{exact:true}));if(!rowCount)return zero.length===1?{status:'no_data',rowCount}:null;const buttons=await visible(root.locator(r.export_selector));return buttons.length===1&&await buttons[0].isEnabled()?{status:'ready',rowCount,button:buttons[0]}:null;},r.picker_timeout_ms,'creative_export_control_not_ready');}
function trace(event,data={}){if(process.env.TIKTOK_EXPORT_TRACE==='1')process.stderr.write(`GMVMAX_CREATIVE_TRACE ${JSON.stringify({event,...data})}\n`);}function expected(r,i,id){return r.filename_template.replace('{{start_date}}',i.startDate).replace('{{end_date}}',i.endDate).replace('{{product_id}}',id);}function inspectOfficial(b,_s,p){const r=p?.official_validation||p;return countXlsxDataRows(b,r.data_start_row);}
async function captureOfficial(dir,filename,r,d={},allowed=[filename]){const end=Date.now()+r.download_timeout_ms,delay=d.delay||((ms)=>new Promise(resolve=>setTimeout(resolve,ms))),names=new Set(allowed);let prior=null,stable=0;do{const entries=fs.readdirSync(dir,{withFileTypes:true});if(entries.some(entry=>!entry.isFile()))fail('official_download_invalid');const complete=entries.filter(entry=>entry.name.toLowerCase().endsWith('.xlsx')),other=entries.filter(entry=>!entry.name.toLowerCase().endsWith('.crdownload')&&!entry.name.toLowerCase().endsWith('.xlsx'));if(other.length||complete.some(entry=>!names.has(entry.name)))fail('official_download_invalid');const match=complete.find(entry=>entry.name===filename);if(match){const file=path.join(dir,filename),stat=fs.statSync(file);if(stat.size>0){const current=`${stat.size}:${stat.mtimeMs}`;stable=current===prior?stable+1:1;prior=current;if(stable>=r.download_capture.stable_polls)return file;}}if(Date.now()>=end)break;await delay(r.download_capture.poll_interval_ms);}while(true);fail('official_download_timeout');}
async function setupCapture(c,dir){let cdp;try{cdp=await c.browserContext.newCDPSession(c.page);await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:dir,eventsEnabled:true});return cdp;}catch{if(cdp?.detach)await cdp.detach().catch(()=>{});fail('official_download_capture_setup_failed');}}
function trackDownloadStarts(cdp){
  const names=new Set();
  cdp.on('Browser.downloadWillBegin',event=>{if(text(event?.suggestedFilename))names.add(event.suggestedFilename);});
  return names;
}
async function downloadStarted(item,dir,names,r){
  const filename=item.started.filename;
  if(names.has(filename)||fs.existsSync(path.join(dir,filename))||fs.existsSync(path.join(dir,`${filename}.crdownload`)))return true;
  return item.started.button.evaluate((button,loadingClass)=>button.classList.contains(loadingClass),r.export_loading_class).catch(()=>false);
}
async function waitForDownloadStarts(items,dir,names,r,d={}){
  const delay=d.delay||((ms)=>new Promise(resolve=>setTimeout(resolve,ms))),end=Date.now()+r.download_start_timeout_ms;
  do{
    const states=await Promise.all(items.map(item=>downloadStarted(item,dir,names,r)));
    const missing=items.filter((_item,index)=>!states[index]);
    if(!missing.length||Date.now()>=end)return missing;
    await delay(r.download_capture.poll_interval_ms);
  }while(true);
}
function failedArtifact(x,e){return{status:'failed',campaign_id:x.campaign.id,campaign_name:x.campaign.name,product_id:x.product.id,product_name:x.product.name,reason_code:e?.code||'creative_performance_artifact_failed'};}
async function openProductPage(c,r,x){
  const target=new URL(r.entry_path,c.origin);
  target.searchParams.set('mpa','1');
  target.searchParams.set(r.campaign_url_query,x.campaign.id);
  target.searchParams.set(r.product_url_query,x.product.id);
  target.searchParams.set(r.product_tab_query,r.product_tab_value);
  await c.page.goto(target.href,{waitUntil:'domcontentloaded',timeout:r.navigation_timeout_ms});
  session(c);
  const current=new URL(c.page.url());
  if(current.searchParams.get(r.campaign_url_query)!==x.campaign.id||current.searchParams.get(r.product_url_query)!==x.product.id||current.searchParams.get(r.product_tab_query)!==r.product_tab_value)fail('product_context_mismatch');
  return x.product;
}
async function startUnit(c,i,d,x,page){
  const r=i.providerSpec.official_validation,worker={...c,page},current=await openProductPage(worker,r,x),dismiss=d.dismissBlockingOverlay||dismissBlockingOverlay;
  if(current.id!==x.product.id)fail('product_context_mismatch');
  await dismiss(page,r.blocking_overlay);
  await(d.applyDateRange||applyDateRange)(page,i.startDate,i.endDate,r);
  await dismiss(page,r.blocking_overlay);
  const state=await creativeState(page,r);
  if(state.status==='no_data'){
    const output_file=path.join(c.outputDir,`${x.campaign.id}_${current.id}_empty.xlsx`);
    writeWorkbook(output_file,[i.reportSpec.headers]);
    const b=fs.readFileSync(output_file);
    return{artifact:{status:'no_data',campaign_id:x.campaign.id,campaign_name:x.campaign.name,product_id:current.id,product_name:current.name,output_file,byte_length:b.length,sha256:sha256(b),generated_file:true,row_count:0,no_data_evidence:i.reportSpec.no_data_rule}};
  }
  const filename=expected(r,i,current.id);
  return{page,current,filename,button:state.button};
}
async function finishUnit(c,i,d,x,started,captureDir,allowed){
  try{
    const output_file=await captureOfficial(captureDir,started.filename,i.providerSpec.official_validation,d,allowed),b=fs.readFileSync(output_file),data_row_count=inspectOfficial(b,i.reportSpec,i.providerSpec.official_validation);
    return{status:'success',campaign_id:x.campaign.id,campaign_name:x.campaign.name,product_id:started.current.id,product_name:started.current.name,output_file,byte_length:b.length,sha256:sha256(b),official_file_unchanged:true,data_row_count,suggested_filename:started.filename};
  }finally{await started.page.close().catch(()=>{});}
}
async function runBatch(c,i,d,units,batchIndex){
  const captureDir=path.join(c.outputDir,`batch_${batchIndex}_capture`);
  if(fs.existsSync(captureDir))fail('official_download_capture_directory_invalid');
  fs.mkdirSync(captureDir);
  const cdp=await setupCapture(c,captureDir),startedNames=trackDownloadStarts(cdp),results=new Array(units.length),pending=[],pages=[];
  try{
    trace('batch_start',{batchIndex,units:units.map(x=>x.product.id),existingPages:c.browserContext.pages().length});
    for(let index=0;index<units.length;index++){
      pages.push(await c.browserContext.newPage());
      trace('page_created',{batchIndex,index,pageCount:c.browserContext.pages().length});
    }
    const attempts=await Promise.all(units.map(async(x,index)=>{
      try{
        const started=await startUnit(c,i,d,x,pages[index]);
        trace('unit_prepared',{batchIndex,index,productId:x.product.id,status:started.artifact?.status||'ready'});
        return{index,x,started};
      }catch(error){
        trace('unit_failed',{batchIndex,index,productId:x.product.id,reason:error?.code||error?.message});
        return{index,x,error};
      }
    }));
    for(const attempt of attempts){
      if(attempt.error){
        if(FATAL.has(attempt.error?.code))throw attempt.error;
        results[attempt.index]=failedArtifact(attempt.x,attempt.error);
      }else if(attempt.started.artifact)results[attempt.index]=attempt.started.artifact;
      else pending.push(attempt);
    }
    const delay=d.delay||((ms)=>new Promise(resolve=>setTimeout(resolve,ms)));
    for(const item of pending){
      await item.started.page.bringToFront();
      await item.started.button.click();
      trace('download_clicked',{batchIndex,index:item.index,productId:item.x.product.id,retry:0});
      await delay(500);
    }
    if(pending.length)await pending[0].started.page.bringToFront();
    for(let retry=1;retry<=i.providerSpec.official_validation.download_retry_limit;retry++){
      const missing=await waitForDownloadStarts(pending,captureDir,startedNames,i.providerSpec.official_validation,d);
      if(!missing.length)break;
      for(const item of missing){
        if(await downloadStarted(item,captureDir,startedNames,i.providerSpec.official_validation))continue;
        await item.started.page.bringToFront();
        await(d.dismissBlockingOverlay||dismissBlockingOverlay)(item.started.page,i.providerSpec.official_validation.blocking_overlay);
        const state=await creativeState(item.started.page,i.providerSpec.official_validation);
        if(state.status!=='ready')continue;
        await state.button.click();
        trace('download_clicked',{batchIndex,index:item.index,productId:item.x.product.id,retry});
        await delay(500);
      }
      if(pending.length)await pending[0].started.page.bringToFront();
    }
    const allowed=pending.map(item=>item.started.filename),settled=await Promise.all(pending.map(async item=>{
      try{return await finishUnit(c,i,d,item.x,item.started,captureDir,allowed);}
      catch(e){if(FATAL.has(e?.code))throw e;return failedArtifact(item.x,e);}
    }));
    for(let n=0;n<pending.length;n++)results[pending[n].index]=settled[n];
    return results;
  }finally{
    for(const page of pages)await page.close().catch(()=>{});
    if(cdp?.detach)await cdp.detach().catch(()=>{});
  }
}
async function run(i,d={}){const c=inputContext(i,d),r=i.providerSpec.official_validation,groups=[];for(const campaign of await campaigns(c,r,i.campaignRef)){const units=[];for(const product of await productChoices(c,r,campaign,i.productRef))units.push({campaign,product});groups.push(units);}if(!groups.some(group=>group.length))fail('product_discovery_failed');const artifacts=[];let batchIndex=1;for(const units of groups)for(let offset=0;offset<units.length;offset+=r.download_batch_size)artifacts.push(...await runBatch(c,i,d,units.slice(offset,offset+r.download_batch_size),batchIndex++));const n=artifacts.filter(a=>a.status==='failed').length,status=artifacts.every(a=>a.status==='no_data')?'no_data':!n?'success':n<artifacts.length?'partial':'failed';return{schema_version:'gmvmax_campaign_product_creative_performance_v3',status,shop_id:String(i.shop.seller_id),seller_id:String(i.shop.seller_id),oec_seller_id:String(i.shop.seller_id),advertiser_id:String(i.advertiserId),business_center_id:String(i.businessCenterId),provider_id:PROVIDER_ID,start_date:i.startDate,end_date:i.endDate,artifacts};}
module.exports={actionRows,applyDateRange,captureOfficial,clickForUrl,creativeState,inspectOfficial,inspectWorkbook:inspectOfficial,monthIndex,monthPanel,run,runBatch,setupCapture,validateSpec};
