'use strict';

const fs = require('fs');
const path = require('path');
const { validateReportSpec } = require('../../common/md-spec-validator');
const { captureOfficialPageCurrency } = require('../../common/currency-contract');
const { writeCsv } = require('../../common/csv');
const { inspectCsv, reportUrl, sha256, validDate } = require('../common/manage_orders_csv_v3');
const { waitForCreatedTask } = require('../common/manage_orders_task_binding');

const PROVIDER_ID = 'local';

function fail(code) { throw Object.assign(new Error(code), { code }); }
function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' && Boolean(value.trim()); }
function getPath(value, fields) { return fields.reduce((current, field) => current?.[field], value); }
function fieldPath(value) { return Array.isArray(value) && value.length && value.every(text); }
function endpoint(value) { return /^\/[a-z0-9_/-]+$/u.test(String(value || '')) && !String(value).includes('//') && !String(value).includes('..'); }
function activePage(page, origin) { try { const url = new URL(page.url()); return url.origin === origin && !/(?:login|signin)(?:\/|$)/iu.test(url.pathname); } catch { return false; } }
function httpsOrigin(value) { try { const url = new URL(value); return url.protocol === 'https:' && url.origin === value; } catch { return false; } }
function timeZone(value) { try { return text(value) && new Intl.DateTimeFormat('en-US', { timeZone: value }).resolvedOptions().timeZone === value; } catch { return false; } }

function validateSpec(spec, providerSpec, options = {}) {
  try { validateReportSpec(spec, options); } catch { fail('orders_report_spec_invalid'); }
  const rules = providerSpec?.official_validation; const ui = rules?.ui_contract; const paths = ui?.response_paths; const query = ui?.entry_query; const retry = providerSpec?.retry_policy;
  if (spec?.report_id !== 'manage_orders_csv' || spec.no_data_rule !== 'official_order_list_total_zero' || spec.providers?.local !== providerSpec
    || providerSpec?.transport !== 'official_ui_download' || !httpsOrigin(providerSpec?.list_response_origin) || !httpsOrigin(providerSpec?.task_response_origin)
    || !object(rules) || !object(ui) || !object(paths) || !object(query) || !object(retry)) fail('orders_report_spec_invalid');
  if (![rules.entry_path, rules.list_endpoint, rules.create_endpoint, rules.record_endpoint].every(endpoint) || !timeZone(rules.business_timezone)
    || !Number.isInteger(rules.data_start_row) || rules.data_start_row < 1 || !text(ui.dialog_selector) || !text(ui.radio_selector)
    || !Number.isInteger(ui.radio_count) || ui.radio_count < 1 || !Array.isArray(ui.required_checked_indices)
    || ui.required_checked_indices.some((value) => !Number.isInteger(value) || value < 0 || value >= ui.radio_count)
    || ![ui.export_button_name, ui.download_button_name, ui.blocking_modal_pattern, ui.download_record_ancestor, ui.seller_query].every(text)
    || ![ui.dialog_attempts, ui.modal_timeout_ms, ui.record_poll_slice_ms, ui.record_poll_min_ms, ui.create_fallback_grace_ms, rules.request_timeout_ms, rules.task_timeout_ms, rules.download_timeout_ms].every((value) => Number.isInteger(value) && value > 0)
    || !['GET', 'POST'].includes(ui.list_method) || !['GET', 'POST'].includes(ui.create_method) || !['GET', 'POST'].includes(ui.record_method)
    || !text(ui.task_id_pattern) || !Array.isArray(ui.task_id_candidate_keys) || !ui.task_id_candidate_keys.length || !ui.task_id_candidate_keys.every(text) || !['list_total', 'create_task_id', 'record_items', 'record_task_id', 'record_file_key', 'record_file_name'].every((key) => fieldPath(paths[key]))
    || !object(query.selected_sort) || !object(query.tab) || !text(query.created_time) || !['selected_sort', 'tab'].every((key) => text(query[key].name) && text(query[key].value))
    || retry.operation_class !== 'official_export_action' || retry.max_total_attempts !== 1 || retry.identity_and_contract_failures_retryable !== false) fail('orders_report_spec_invalid');
  try { new RegExp(ui.blocking_modal_pattern, 'iu'); new RegExp(ui.task_id_pattern, 'u'); } catch { fail('orders_report_spec_invalid'); }
  return spec;
}

function assertSession(context) {
  if (!context.browser?.isConnected?.()) fail('browser_disconnected');
  if (!context.browserContext || !context.browser.contexts?.().includes(context.browserContext)) fail('browser_context_missing');
  if (!context.browserContext.pages().includes(context.page)) fail('seller_page_missing');
  if (!activePage(context.page, context.sellerOrigin)) fail('seller_origin_mismatch');
}

function assertFailureSession(input, dependencies) {
  if (!dependencies.browser?.isConnected?.()) fail('browser_disconnected');
  if (!dependencies.browserContext || !dependencies.browser.contexts?.().includes(dependencies.browserContext)) fail('browser_context_missing');
  let origin; try { origin = new URL(input?.b?.seller_page_url).origin; } catch { return; }
  const pages = dependencies.browserContext.pages?.() || [];
  if (pages.some((page) => activePage(page, origin))) return;
  if (pages.some((page) => { try { const url = new URL(page.url()); return url.origin === origin && /(?:login|signin)(?:\/|$)/iu.test(url.pathname); } catch { return false; } })) fail('seller_login_page');
  fail('seller_origin_mismatch');
}

async function waitList(page, providerSpec, sellerId, timeout, ui) {
  const rules = providerSpec.official_validation;
  const response = await page.waitForResponse((item) => { try { const url = new URL(item.url()); return item.request().method() === ui.list_method && url.origin === providerSpec.list_response_origin && url.pathname === rules.list_endpoint && url.searchParams.get(ui.seller_query) === String(sellerId) && item.status() === 200; } catch { return false; } }, { timeout })
    .catch((error) => { if (error?.name === 'TimeoutError') fail('order_list_response_not_observed'); throw error; });
  const body = await response.json().catch(() => null); const total = getPath(body, ui.response_paths.list_total);
  return { response, total: Number.isInteger(total) ? total : null };
}

async function exportDialog(page, ui) {
  const modalPattern = new RegExp(ui.blocking_modal_pattern, 'iu');
  for (let attempt = 0; attempt < ui.dialog_attempts; attempt += 1) {
    const dialogs = page.locator(ui.dialog_selector);
    for (let index = 0; index < await dialogs.count(); index += 1) {
      const dialog = dialogs.nth(index);
      if (await dialog.locator(ui.radio_selector).count() === ui.radio_count && await dialog.getByRole('button', { name: ui.export_button_name, exact: true }).count()) return dialog;
      const label = (await dialog.getByRole('button').allInnerTexts()).find((value) => modalPattern.test(String(value).trim()));
      if (!label) fail('blocking_modal_contract_changed');
      await dialog.getByRole('button', { name: label, exact: true }).click(); await dialog.waitFor({ state: 'hidden', timeout: ui.modal_timeout_ms });
    }
    await page.getByRole('button', { name: ui.export_button_name, exact: true }).first().click();
  }
  fail('export_dialog_contract_changed');
}

async function waitTask(page, providerSpec, taskId, timeout, ui) {
  const rules = providerSpec.official_validation; const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const response = await page.waitForResponse((item) => { try { const url = new URL(item.url()); return item.request().method() === ui.record_method && url.origin === providerSpec.task_response_origin && url.pathname === rules.record_endpoint; } catch { return false; } }, { timeout: Math.min(ui.record_poll_slice_ms, Math.max(ui.record_poll_min_ms, deadline - Date.now())) }).catch(() => null);
    if (!response || response.status() !== 200) continue;
    const body = await response.json().catch(() => null); if (body?.code !== 0) continue;
    const records = getPath(body, ui.response_paths.record_items); if (!Array.isArray(records)) continue;
    const matches = records.filter((item) => String(getPath(item, ui.response_paths.record_task_id)) === taskId);
    if (matches.length > 1) fail('export_record_ambiguous');
    if (getPath(matches[0], ui.response_paths.record_file_key)) return matches[0];
  }
  fail('export_task_timeout');
}

async function waitRecords(page, providerSpec, timeout, ui) {
  const rules = providerSpec.official_validation; const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const response = await page.waitForResponse((item) => { try { const url = new URL(item.url()); return item.request().method() === ui.record_method && url.origin === providerSpec.task_response_origin && url.pathname === rules.record_endpoint; } catch { return false; } }, { timeout: Math.min(ui.record_poll_slice_ms, Math.max(ui.record_poll_min_ms, deadline - Date.now())) }).catch(() => null);
    if (!response || typeof response.status === 'function' && response.status() !== 200) continue;
    const body = await response.json().catch(() => null); const records = getPath(body, ui.response_paths.record_items);
    if (Array.isArray(records)) return records;
  }
  fail('export_task_timeout');
}

async function waitPageCurrency(page, contract, timeout, dependencies = {}) {
  const deadline = Date.now() + timeout;
  const delay = dependencies.delay || ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  do {
    try { return await captureOfficialPageCurrency(page, contract, dependencies); }
    catch (error) { if (error?.code !== 'currency_evidence_missing') throw error; }
    if (Date.now() >= deadline) break;
    await delay(Math.min(100, Math.max(1, deadline - Date.now())));
  } while (true);
  fail('currency_evidence_missing');
}

async function runInner(input, dependencies = {}) {
  if (input?.shop?.provider_id !== PROVIDER_ID) fail('report_provider_unsupported');
  validateSpec(input?.reportSpec, input?.providerSpec, { skillRoot: dependencies.skillRoot });
  const spec = input.reportSpec; const providerSpec = input.providerSpec; const rules = providerSpec.official_validation; const ui = rules.ui_contract;
  if (!object(input.a) || !object(input.b) || !object(input.shop) || !/^\d+$/u.test(String(input.shop.seller_id || '')) || !validDate(input.startDate) || !validDate(input.endDate)
    || input.startDate > input.endDate || !dependencies.browser || !dependencies.browserContext) fail('orders_input_invalid');
  const outputDir = path.resolve(String(input.outputDir || ''));
  if (!fs.statSync(outputDir, { throwIfNoEntry: false })?.isDirectory() || fs.readdirSync(outputDir).length) fail('output_directory_invalid');
  let sellerOrigin; try { const sellerUrl = new URL(input.b.seller_page_url); if (sellerUrl.protocol !== 'https:') fail('provider_binding_invalid'); sellerOrigin = sellerUrl.origin; } catch (error) { if (error?.code) throw error; fail('provider_binding_invalid'); }
  if (sellerOrigin !== providerSpec.list_response_origin || sellerOrigin !== providerSpec.task_response_origin) fail('seller_origin_mismatch');
  const page = dependencies.browserContext.pages().find((candidate) => activePage(candidate, sellerOrigin));
  if (!page) fail('seller_page_missing');
  const context = { browser: dependencies.browser, browserContext: dependencies.browserContext, page, sellerOrigin }; assertSession(context);
  const listPromise = waitList(page, providerSpec, input.shop.seller_id, rules.request_timeout_ms, ui);
  try { await page.goto(reportUrl(sellerOrigin, rules.entry_path, input.startDate, input.endDate, rules.business_timezone, ui).href, { waitUntil: 'commit', timeout: rules.request_timeout_ms }); }
  catch (error) { void listPromise.catch(() => {}); if (error?.name === 'TimeoutError') fail('order_page_navigation_timeout'); throw error; }
  const { response, total } = await listPromise; assertSession(context);
  const responseUrl = new URL(response.url());
  if (responseUrl.origin !== providerSpec.list_response_origin || responseUrl.pathname !== rules.list_endpoint || responseUrl.searchParams.get(ui.seller_query) !== String(input.shop.seller_id)) fail('result_shop_identity_mismatch');
  const identity = { shop_id: String(input.shop.seller_id), seller_id: String(input.shop.seller_id), oec_seller_id: String(input.shop.seller_id), provider_id: PROVIDER_ID };
  const currencyEvidence = await waitPageCurrency(page, spec.currency_contract, rules.request_timeout_ms, dependencies);
  if (total === 0) {
    const outputFile = path.join(outputDir, 'orders_empty.csv'); writeCsv(outputFile, [spec.headers], { bom: true }); const buffer = fs.readFileSync(outputFile);
    return { schema_version: 'manage_orders_csv_v3', status: 'no_data', ...identity, output_file: outputFile, byte_length: buffer.length, sha256: sha256(buffer), generated_file: true, row_count: 0, no_data_evidence: spec.no_data_rule, currency_evidence: currencyEvidence };
  }
  const dialog = await exportDialog(page, ui); const radios = dialog.locator(ui.radio_selector);
  for (const index of ui.required_checked_indices) if (!(await radios.nth(index).isChecked())) fail('export_defaults_changed');
  let clickStarted = false; const createdTask = waitForCreatedTask(page, providerSpec, rules.request_timeout_ms, ui, () => clickStarted, dependencies.delay);
  clickStarted = true; const [, created] = await Promise.all([dialog.getByRole('button', { name: ui.export_button_name, exact: true }).click(), createdTask]);
  const { taskId } = created; const record = await waitTask(page, providerSpec, taskId, rules.task_timeout_ms, ui);
  let recordFilename; try { recordFilename = decodeURIComponent(getPath(record, ui.response_paths.record_file_name) || ''); } catch { fail('export_record_mismatch'); }
  if (!text(recordFilename)) fail('export_record_mismatch');
  const nameMatches = dialog.getByText(recordFilename, { exact: true }); if (await nameMatches.count() !== 1) fail('export_record_mismatch');
  const button = nameMatches.first().locator(ui.download_record_ancestor).getByRole('button', { name: ui.download_button_name, exact: true });
  if (await button.count() !== 1) fail('export_record_mismatch');
  const pending = page.waitForEvent('download', { timeout: rules.download_timeout_ms }); await button.click(); const download = await pending; assertSession(context);
  const stream = await download.createReadStream(); const chunks = []; for await (const chunk of stream) chunks.push(chunk);
  const buffer = Buffer.concat(chunks); const dataRowCount = inspectCsv(buffer, spec, providerSpec); const hash = sha256(buffer); const outputFile = path.join(outputDir, `${taskId}.csv`);
  fs.writeFileSync(outputFile, buffer, { flag: 'wx' }); if (sha256(fs.readFileSync(outputFile)) !== hash) fail('official_file_changed');
  return { schema_version: 'manage_orders_csv_v3', status: 'success', ...identity, task_id: taskId, output_file: outputFile, byte_length: buffer.length, sha256: hash, official_file_unchanged: true, data_row_count: dataRowCount, currency_evidence: currencyEvidence };
}

async function run(input, dependencies = {}) { try { return await runInner(input, dependencies); } catch (error) { if (dependencies.browser) assertFailureSession(input, dependencies); throw error; } }

module.exports = { inspectCsv, run, validateSpec, waitPageCurrency, waitRecords, waitTask };
