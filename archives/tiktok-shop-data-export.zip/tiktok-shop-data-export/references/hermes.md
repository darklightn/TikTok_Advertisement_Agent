# Hermes v3 entry

Hermes submits the same v3 request accepted by `scripts/export.js`:

```json
{
  "shop": "exact shop reference",
  "report_scopes": ["report alias or narrow scope"],
  "start_date": "YYYY-MM-DD",
  "end_date": "YYYY-MM-DD",
  "advertiser": "optional exact advertiser",
  "campaign": "optional exact campaign",
  "product": "optional exact product"
}
```

Invoke the thin adapter with:

```text
node scripts/i_hermes_tool_export.js --request-json '<v3 JSON>'
```

For a syntactically valid JSON request it emits one `ack` event, passes the request unchanged to `scripts/export.js`, and then emits exactly one `final` event. The final event preserves the complete `export_result_v1`: overall `success`, `no_data`, `partial`, or `failed`; ordered report IDs; each report's status, files, row count, hash or reason; and every multi-artifact terminal result.

If request validation fails before a run context exists, the failed final keeps the validation `reason_code` (for example, `date_range_required`) even though `request_id`, `shop_id`, and the report terminal list are not yet available.

Invalid JSON emits one failed final event without an acknowledgment. Scope and report capabilities come only from [report-router.md](report-router.md) and its report specifications; this adapter does not maintain a second capability list.

The adapter passes the v3 request through unchanged and persists no task state.
